# Models (source_id)

Registered CMIP models (Stage 4 output).

**Records:** 2

| Id | Name | Description | Family | Release Year | Dynamic Components | Prescribed Components | Omitted Components | Component Configs | Embedded Components | Coupling Groups | Calendar | References |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| **land_ice** | ** | Land Ice | ** | ** | ** | ** | ** | ** | ** | ** | ** | ** |
| **standard** | ** | Mixed Gregorian/Julian calendar as defined by U... | ** | ** | ** | ** | ** | ** | ** | ** | ** | ** |

*Generated: 2026-02-24 23:36*